# Address Book in Python

**Topic:** Development of an Address Book Application Using Python

A menu-driven Python application for adding, viewing, searching, updating and deleting contact information.

## Features
- Add, View, Search, Update and Delete contacts
- Input validation
- Permanent storage using JSON file handling

## Technologies
Python 3, JSON, File Handling, Git and GitHub

## Run
Open a terminal in this folder and run:
`python main.py`

## Four Presentation Modules
1. Project Setup and Menu
2. Add and View Contacts
3. Search, Update and Delete
4. Validation, Permanent Storage and Testing

## Future Scope
Tkinter GUI, SQLite/MySQL database, login, import/export, sorting/filtering, Flask/Django web version.
